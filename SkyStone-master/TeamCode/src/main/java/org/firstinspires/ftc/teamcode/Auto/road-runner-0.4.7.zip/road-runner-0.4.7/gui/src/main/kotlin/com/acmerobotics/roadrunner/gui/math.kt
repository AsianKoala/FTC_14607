package com.acmerobotics.roadrunner.gui

fun Double.toDegrees() = Math.toDegrees(this)

fun Double.toRadians() = Math.toRadians(this)
